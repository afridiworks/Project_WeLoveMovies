const router = require("express").Router({ mergeParams: true });
const controller = require("./movies.controller");
const methodNotAllowed = require("../errors/methodNotAllowed");
const { route } = require("../app");

router.route("/").get(controller.list).all(methodNotAllowed);

router.route("/movies/:movieId").get(controller.list).all(methodNotAllowed);

module.exports = router;
